# dti-chembl

Drug target identification using activities from CHEMBL database

## Data  url

/Drive/DTI-Practicum-Documents/ic50.csv
