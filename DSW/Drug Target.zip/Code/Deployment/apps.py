from django.apps import AppConfig


class DrugsConfig(AppConfig):
    name = 'drugs'
